# Optimal Browser Source Code

This repository contains the updated source code for Optimal Browser (`com.dev.optimal`).
