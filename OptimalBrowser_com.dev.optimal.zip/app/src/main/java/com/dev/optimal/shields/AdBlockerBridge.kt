package com.dev.optimal.shields

import android.content.Context
import androidx.preference.PreferenceManager

class AdBlockerBridge(private val context: Context) {

    private val prefs = PreferenceManager.getDefaultSharedPreferences(context)

    fun isAdBlockerEnabled(): Boolean {
        return prefs.getBoolean("key_ad_blocker", true)
    }

    fun setAdBlockerEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("key_ad_blocker", enabled).apply()
    }
}
