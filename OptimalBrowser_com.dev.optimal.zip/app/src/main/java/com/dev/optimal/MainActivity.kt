package com.dev.optimal

import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.widget.ImageButton
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dev.optimal.data.DataSaverManager
import com.dev.optimal.shields.AdBlockerBridge
import com.dev.optimal.ui.SpeedDialAdapter
import com.dev.optimal.ui.settings.SettingsActivity

class MainActivity : AppCompatActivity() {

    private lateinit var adBlocker: AdBlockerBridge
    private lateinit var dataSaver: DataSaverManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        adBlocker = AdBlockerBridge(this)
        dataSaver = DataSaverManager(this)

        setupSpeedDial()
        setupBottomBar()
    }

    private fun setupSpeedDial() {
        val speedDialRv = findViewById<RecyclerView>(R.id.rv_speed_dial)
        speedDialRv.layoutManager = GridLayoutManager(this, 4)
        
        val defaultSites = listOf(
            "Facebook" to "https://facebook.com",
            "Google" to "https://google.com",
            "Instagram" to "https://instagram.com",
            "YouTube" to "https://youtube.com",
            "GitHub" to "https://github.com",
            "Pinterest" to "https://pinterest.com"
        )
        
        speedDialRv.adapter = SpeedDialAdapter(defaultSites) { url ->
            // Open WebView or Engine
        }
    }

    private fun setupBottomBar() {
        val btnSettings = findViewById<ImageButton>(R.id.btn_profile)
        btnSettings?.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    fun setCustomWallpaper(drawable: Drawable) {
        val wallpaperView = findViewById<ImageView>(R.id.iv_home_wallpaper)
        wallpaperView?.apply {
            setImageDrawable(drawable)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
    }
}
