package com.dev.optimal.tabs

data class TabGroup(
    val groupName: String,
    val tabCount: Int,
    val isPrivate: Boolean = false
)

class TabManager {

    private val regularTabGroups = mutableListOf<TabGroup>()
    private val privateTabGroups = mutableListOf<TabGroup>()

    fun createTabGroup(name: String, isPrivate: Boolean) {
        val group = TabGroup(groupName = name, tabCount = 1, isPrivate = isPrivate)
        if (isPrivate) {
            privateTabGroups.add(group)
        } else {
            regularTabGroups.add(group)
        }
    }
}
