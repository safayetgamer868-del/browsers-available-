package com.dev.optimal.data

import android.content.Context
import androidx.preference.PreferenceManager

class DataSaverManager(context: Context) {

    private val prefs = PreferenceManager.getDefaultSharedPreferences(context)

    fun isDataSaverEnabled(): Boolean {
        return prefs.getBoolean("key_data_saver", true)
    }

    fun applyDataSavingHeaders(headers: MutableMap<String, String>) {
        if (isDataSaverEnabled()) {
            headers["Save-Data"] = "on"
            headers["Accept-Encoding"] = "gzip, deflate, br"
        }
    }
}
